const baseAPIPDF = process.env.REACT_APP_API_BASE_URL

export default baseAPIPDF
